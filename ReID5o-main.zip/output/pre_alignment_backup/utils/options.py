import argparse

def get_args():
    parser = argparse.ArgumentParser(description="ReID5o")
    ######################## general settings ########################
    parser.add_argument("--local_rank", default=0, type=int)
    parser.add_argument("--name", default="ORBench", help="experiment name to save")
    parser.add_argument("--output_dir", default="logs",
                    help="Output directory. When 'logs', auto-generates logs/YYYYMMDD_DATASET_HH_MM (e.g. logs/20260219_ICFG_PEDES_18_42)")
    parser.add_argument("--log_period", default=500)
    parser.add_argument("--eval_period", default=2)
    parser.add_argument("--val_dataset", default="test") # use val set when evaluate, if test use test set
    parser.add_argument("--resume", default=False, action='store_true')
    parser.add_argument("--resume_ckpt_file", default="", help='resume from ...')

    ######################## model general settings ########################
    parser.add_argument("--pretrain_choice", default='ViT-B/16') # whether use pretrained model
    parser.add_argument("--temperature", type=float, default=0.02, help="initial temperature value, if 0, don't use temperature")
    parser.add_argument("--img_aug", default=False, action='store_true')
    parser.add_argument("--add_lora", default=False, action='store_true')
    parser.add_argument("--freeze_vision_encoder", default=False, action='store_true')
    parser.add_argument("--lora_r", type=int,default=4)
    parser.add_argument("--num_loras", type=int, default=4)
    parser.add_argument("--lora_layers", type=int, default=2)
    parser.add_argument("--lora_mode", type=str, default='mlp')

    parser.add_argument("--mmt_depth", type=int, default=4, help="for multimodal feature fusion")

    ######################## Missing-aware Robust Encoding settings ########################
    parser.add_argument("--use_missing_aware", default=True, action='store_true',
                        help="Enable Missing-aware Robust Encoding for handling arbitrary missing modalities")
    parser.add_argument("--modality_dropout_prob", type=float, default=0.3,
                        help="Probability of dropping each non-RGB modality during training (reduced from 0.5 to preserve more complete training signal)")
    parser.add_argument("--keep_rgb_prob", type=float, default=0.9,
                        help="Probability of keeping RGB modality (gallery modality, increased for stability)")
    parser.add_argument("--min_modalities_keep", type=int, default=2,
                        help="Minimum number of modalities to keep during training (increased from 1 for better learning)")
    parser.add_argument("--consistency_loss_weight", type=float, default=0.1,
                        help="Weight for consistency loss (reduced from 0.5 to not dominate main losses)")
    parser.add_argument("--consistency_loss_type", type=str, default='cosine',
                        choices=['l2', 'cosine', 'both'],
                        help="Type of consistency loss: 'l2', 'cosine', or 'both'")
    parser.add_argument("--consistency_temperature", type=float, default=0.1,
                        help="Temperature for cosine consistency loss")
    parser.add_argument("--modality_dropout_warmup_epochs", type=int, default=5,
                        help="Number of epochs to train without modality dropout (warmup phase)")

    ######################## Cross-modal Feature Completion settings ########################
    parser.add_argument("--use_cross_modal_completion", default=True, action='store_true',
                        help="Enable Cross-modal Feature Completion for generating missing modality features")
    parser.add_argument("--completion_num_heads", type=int, default=8,
                        help="Number of attention heads in completion generators")
    parser.add_argument("--completion_num_layers", type=int, default=2,
                        help="Number of layers in each completion generator")
    parser.add_argument("--completion_dropout", type=float, default=0.1,
                        help="Dropout rate in completion module")
    parser.add_argument("--completion_recon_loss_weight", type=float, default=0.3,
                        help="Weight for reconstruction loss in completion training (reduced from 1.0)")
    parser.add_argument("--completion_cycle_loss_weight", type=float, default=0.1,
                        help="Weight for cycle consistency loss in completion training (reduced from 0.5)")
    parser.add_argument("--completion_loss_type", type=str, default='cosine',
                        choices=['l2', 'l1', 'cosine', 'combined'],
                        help="Type of loss for completion: 'l2', 'l1', 'cosine', or 'combined'")
    parser.add_argument("--use_completion_inference", default=True, action='store_true',
                        help="Use completion during inference to generate missing modality features")
    parser.add_argument("--completion_warmup_epochs", type=int, default=3,
                        help="Number of epochs before enabling completion loss (let main task converge first)")

    ######################## Reliability-Adaptive Fusion settings ########################
    parser.add_argument("--use_reliability_fusion", default=True, action='store_true',
                        help="Enable Reliability-Adaptive Fusion for intelligent modality weighting")
    parser.add_argument("--reliability_hidden_dim", type=int, default=256,
                        help="Hidden dimension for reliability estimator network")
    parser.add_argument("--reliability_num_heads", type=int, default=8,
                        help="Number of attention heads for fusion transformer")
    parser.add_argument("--reliability_num_layers", type=int, default=2,
                        help="Number of transformer layers for fusion refinement")
    parser.add_argument("--use_quality_indicators", default=True, action='store_true',
                        help="Use quality indicators (variance, norm, confidence) for reliability estimation")
    parser.add_argument("--use_transformer_refinement", default=True, action='store_true',
                        help="Use transformer for post-fusion refinement")
    parser.add_argument("--fusion_sparsity_weight", type=float, default=0.01,
                        help="Weight for sparsity regularization loss (reduced from 0.1)")
    parser.add_argument("--fusion_uncertainty_weight", type=float, default=0.02,
                        help="Weight for uncertainty-aware loss (reduced from 0.2)")
    parser.add_argument("--fusion_sparsity_target", type=float, default=0.3,
                        help="Target sparsity level (0=all equal, 1=single modality)")
    parser.add_argument("--fusion_sparsity_type", type=str, default='entropy',
                        choices=['entropy', 'l1', 'gini'],
                        help="Type of sparsity regularization")
    parser.add_argument("--use_reliability_fusion_inference", default=False, action='store_true',
                        help="Use reliability-adaptive fusion during inference (default: False, as fusion is primarily for training regularization)")
    parser.add_argument("--fusion_warmup_epochs", type=int, default=5,
                        help="Number of epochs before enabling fusion regularization losses")

    ######################## loss settings ########################
    parser.add_argument("--loss_names", default='mm_sdm+id', help="which loss to use [ 'cmpm', 'itc', 'sdm','pretrain']")
    parser.add_argument("--id_loss_weight", type=float, default=1.0)
    ######################## vison trainsformer settings ########################
    parser.add_argument("--img_size", type=tuple, default=(384, 128))
    parser.add_argument("--stride_size", type=int, default=16)

    ######################## text transformer settings ########################
    parser.add_argument("--text_length", type=int, default=77)
    parser.add_argument("--vocab_size", type=int, default=49408)

    ######################## solver ########################
    parser.add_argument("--optimizer", type=str, default="Adam", help="[SGD, Adam, Adamw]")
    parser.add_argument("--lr", type=float, default=1e-5)
    parser.add_argument("--bias_lr_factor", type=float, default=2.)
    parser.add_argument("--lora_lr_factor", type=float, default=5.0, help="lr factor for random init LoRAs")
    parser.add_argument("--momentum", type=float, default=0.9)
    parser.add_argument("--weight_decay", type=float, default=4e-5)
    parser.add_argument("--weight_decay_bias", type=float, default=0.)
    parser.add_argument("--alpha", type=float, default=0.9)
    parser.add_argument("--beta", type=float, default=0.999)
    
    ######################## scheduler ########################
    parser.add_argument("--num_epoch", type=int, default=20)
    parser.add_argument("--milestones", type=int, nargs='+', default=(20,50))
    parser.add_argument("--gamma", type=float, default=0.1)
    parser.add_argument("--warmup_factor", type=float, default=0.1)
    parser.add_argument("--warmup_epochs", type=int, default=5)
    parser.add_argument("--warmup_method", type=str, default="linear")
    parser.add_argument("--lrscheduler", type=str, default="cosine")
    parser.add_argument("--target_lr", type=float, default=0)
    parser.add_argument("--power", type=float, default=0.9)

    ######################## dataset ########################
    parser.add_argument("--dataset_name", default="ORBench", 
                        help="Dataset name: [ORBench, CUHK-PEDES, ICFG-PEDES, RSTPReid]")
    parser.add_argument("--num_modalities", type=int, default=5,
                        help="Number of modalities in dataset: 5 for ORBench, 3 for CUHK-PEDES/ICFG-PEDES/RSTPReid")
    parser.add_argument("--force_missing_nir_cp", default=False, action='store_true',
                        help="Force NIR and CP modalities to be treated as always missing (for 3-modal datasets)")
    parser.add_argument("--sampler", default="random", help="choose sampler from [random]")
    parser.add_argument("--num_instance", type=int, default=4)
    parser.add_argument("--root_dir", default="./data")
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--test_batch_size", type=int, default=512)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--test", dest='training', default=True, action='store_false')
    
    ######################## evaluation ########################
    parser.add_argument("--compute_mAP", default=False, action='store_true',
                        help="Compute mAP and mINP during evaluation (slower but more comprehensive)")

    args = parser.parse_args()

    return args
