"""Read-only audit probes. Uses only Python's standard library; never extracts ZIPs."""
from pathlib import Path
from zipfile import ZipFile
from collections import Counter
import argparse
import ast
import json
import random
import sys
import types
import typing


ROOT = Path(__file__).resolve().parents[2]


def run():
    sources = list(ROOT.rglob("*.py"))
    source_errors = []
    for path in sources:
        try:
            ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        except (SyntaxError, UnicodeError) as exc:
            source_errors.append({"path": str(path), "error": str(exc)})

    options_tree = ast.parse((ROOT / "utils/options.py").read_text(encoding="utf-8-sig"))
    option_ns = {"argparse": argparse}
    exec(compile(ast.Module(body=[n for n in options_tree.body
                                 if isinstance(n, ast.FunctionDef) and n.name == "get_args"],
                            type_ignores=[]), "utils/options.py", "exec"), option_ns)
    original_argv = sys.argv[:]
    try:
        sys.argv = ["audit"]
        args = option_ns["get_args"]()
    finally:
        sys.argv = original_argv
    defaults = {key: getattr(args, key) for key in (
        "add_lora", "num_loras", "num_epoch", "compute_mAP", "use_missing_aware",
        "use_cross_modal_completion", "use_reliability_fusion",
        "use_reliability_fusion_inference", "use_transformer_refinement",
        "min_modalities_keep", "modality_dropout_prob", "keep_rgb_prob")}

    # Execute the actual class methods with object as the otherwise unused nn.Module base.
    # No tensor operations or PyTorch imports are involved in these methods.
    dropout_tree = ast.parse((ROOT / "model/missing_aware_encoding.py").read_text(encoding="utf-8-sig"))
    dropout_ns = {"nn": types.SimpleNamespace(Module=object), "random": random, "List": typing.List}
    exec(compile(ast.Module(body=[n for n in dropout_tree.body
                                 if isinstance(n, ast.ClassDef) and n.name == "ModalityDropout"],
                            type_ignores=[]), "model/missing_aware_encoding.py", "exec"), dropout_ns)
    dropout = dropout_ns["ModalityDropout"](
        num_modalities=5, min_keep=args.min_modalities_keep,
        dropout_prob=args.modality_dropout_prob, keep_rgb_prob=args.keep_rgb_prob)
    empty_masks = []
    for seed in range(10000):
        random.seed(seed)
        raw = dropout.forward(training=True)
        filtered = raw[:]
        # Exact three-modal filtering performed by build.py:558-560.
        filtered[1] = filtered[2] = False
        if not any(filtered):
            empty_masks.append({"seed": seed, "before_filter": raw, "after_filter": filtered})

    names = ("compute_reliability_fusion_with_completion", "get_reliability_fused_feature",
             "get_completed_single_modality_features", "complete_missing_features",
             "compute_reliability_fusion")
    calls = {name: [] for name in names}
    for path in sources:
        if path == Path(__file__).resolve():
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8-sig"))):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in calls:
                calls[node.func.attr].append(f"{path.relative_to(ROOT).as_posix()}:{node.lineno}")

    result = {
        "scope": "Static source and ZIP-directory/annotation checks; no model or retrieval evaluation",
        "python_syntax": {"files_including_this_probe": len(sources), "errors": source_errors},
        "parsed_defaults": defaults,
        "three_modal_empty_mask_probe": {
            "seeded_draws": 10000, "empty_after_filter": len(empty_masks),
            "first_counterexample": empty_masks[0] if empty_masks else None,
            "note": "Seed sweep demonstrates a reachable bug; this is not a measured training failure rate."},
        "ast_call_sites": calls,
        "archives": [],
        "annotation_checks": [],
    }
    for path in sorted((ROOT / "data").glob("*.zip")):
        with ZipFile(path) as archive:
            entries = archive.infolist()
            result["archives"].append({
                "path": str(path), "compressed_bytes": path.stat().st_size,
                "entries": len(entries), "uncompressed_bytes": sum(x.file_size for x in entries),
                "first_paths": [x.filename for x in entries[:3]],
            })

    sketch_zip = ROOT / "data/Tri-CUHK-PEDES, Tri-ICFG-PEDES, and Tri-RSTPReid.zip"
    if sketch_zip.exists():
        with ZipFile(sketch_zip) as archive:
            sketch_paths = [p for p in archive.namelist() if not p.endswith("/")]
        specs = [
            ("CUHK-PEDES.zip", "CUHK-PEDES/caption_all.json", "file_path", "sketch/aliyun/CUHK/imgs/"),
            ("ICFG-PDES.zip", "ICFG-PEDES/ICFG-PEDES.json", "file_path", "sketch/aliyun/ICFG/imgs/"),
            ("RSTPReid.zip", "data_captions.json", "img_path", "sketch/aliyun/RSTPReid/imgs/"),
        ]
        for filename, annotation, path_key, sketch_prefix in specs:
            archive_path = ROOT / "data" / filename
            if not archive_path.exists():
                continue
            with ZipFile(archive_path) as archive:
                rows = json.loads(archive.read(annotation))
            sk = {p[len(sketch_prefix):] for p in sketch_paths if p.startswith(sketch_prefix)}
            basenames = {p.rsplit("/", 1)[-1] for p in sk}
            unmatched = [x for x in rows if x[path_key].replace("\\", "/") not in sk
                         and x[path_key].replace("\\", "/").rsplit("/", 1)[-1] not in basenames]
            item = {
                "archive": filename, "annotation": annotation,
                "rows": len(rows), "identities": len({x["id"] for x in rows}),
                "annotation_split_counts": dict(Counter(x.get("split", "MISSING") for x in rows)),
                "sketch_files": len(sk), "extension_sensitive_unmatched": len(unmatched),
                "unmatched_examples": [x[path_key] for x in unmatched[:4]],
            }
            if filename == "CUHK-PEDES.zip":
                def split(row):
                    path = row[path_key].lower()
                    return "train" if "train" in path else "val" if "val" in path else "test" if "test" in path else "train"
                partitions = {s: [x for x in rows if split(x) == s] for s in ("train", "val", "test")}
                item["current_loader_partition"] = {
                    s: {"images": len(v), "identities": len({x["id"] for x in v})}
                    for s, v in partitions.items()}
                item["train_test_identity_overlap"] = len(
                    {x["id"] for x in partitions["train"]} & {x["id"] for x in partitions["test"]})
                item["unmatched_by_current_loader_partition"] = dict(Counter(split(x) for x in unmatched))
            result["annotation_checks"].append(item)
    orbench_path = ROOT / "data/ORBench.zip"
    if orbench_path.exists():
        with ZipFile(orbench_path) as archive:
            train = json.loads(archive.read("ORBench/train_annos.json"))
            test = json.loads(archive.read("ORBench/test_gallery_and_queries.json"))
        train_ids = {str(x["id"]) for x in train}
        gallery_ids = {str(x[0]) for x in test["RGB_GALLERY"]}
        train_folders = {x["file_path"].split("/")[1] for x in train}
        test_folders = {x[1].split("/")[1] for x in test["RGB_GALLERY"]}
        result["annotation_checks"].append({
            "archive": "ORBench.zip", "train_rows": len(train),
            "train_identities": len(train_ids), "gallery_rows": len(test["RGB_GALLERY"]),
            "gallery_identities": len(gallery_ids),
            "train_test_label_overlap": len(train_ids & gallery_ids),
            "train_test_person_folder_overlap": len(train_folders & test_folders),
            "total_person_folders": len(train_folders | test_folders),
            "query_counts": {k: len(v) for k, v in test.items() if k != "RGB_GALLERY"},
            "json_keys": list(test),
        })
    return result


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    result = run()
    destination = Path(__file__).with_name("audit_checks.json")
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
