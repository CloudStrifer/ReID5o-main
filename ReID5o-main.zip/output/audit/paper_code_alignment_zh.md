# 历史核查记录（实现修改之前）

此报告保留首次核查结论；后续实现进度请看 `Docs/README.md`。下列代码链接改为实现前备份，避免旧行号误指向新代码。

# 论文与当前代码一致性核查

核查日期：2026-10-26。对象：[论文 TeX](E:/Download/elsarticle-template-num.tex)、[编译 PDF](E:/Download/manuscript_PR.pdf)、`E:/Code/ReID5o-main` 中的实现，以及核查时 `data` 下已有压缩包的目录和标注。没有修改原论文或模型代码，没有解压数据集，没有运行模型训练或检索评估。

**结论：存在影响方法定义、训练目标和实验复现的实质差异。当前实现不能直接视为论文所描述的完整 MFCRAF。此次排查不需要继续复制或解压完整数据集。优先找回生成论文结果的代码快照、配置与日志，再决定补实现还是修论文。**

这不等于判定论文中的数值错误，更不能据此推断实验没有做过。当前目录没有历史实验配置、权重或日志，无法确定它是否就是产生表格结果的版本。下面把代码可直接确认的事实与仍需实验记录的事项分开。

## 1. 目前实际执行的路径

| 阶段 | 当前实现 |
|---|---|
| 主训练路径 | CLIP 特征 → 缺失状态嵌入/缺失 token → 原有 `mm_fusion` 组合特征 → SDM、ID。|
| 补全训练 | 另取单模态特征，计算 reconstruction、cycle 辅助损失；生成结果没有进入主 SDM、ID 特征。|
| 可靠性训练 | 计算 sparsity、uncertainty 辅助损失；返回的融合表示被丢弃。|
| 评估 gallery | `encode_rgb_cls`，仅 RGB，未经过论文所述统一补全和可靠性融合路径。|
| 评估单模态 query | 缺失感知特征；默认开启补全时，尝试加入生成 RGB：`0.7 × 原特征 + 0.3 × 生成 RGB`。|
| 评估多模态 query | 仅编码已提供的模态，拼接 token 后调用原有 `mm_fusion`；没有调用 CMC、RAF。|
| 可视化检索 `infer.py` | 普通编码器 + CLS / `mm_fusion`，与 `Evaluator` 的缺失感知及单模态补全逻辑不同。|

主要证据：[训练主路](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:978)、[补全辅助损失](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1083)、[融合结果丢弃](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1125)、[单模态评估](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/metrics.py:93)、[多模态评估](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/metrics.py:184)、[gallery](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/metrics.py:268)、[可视化推理](E:/Code/ReID5o-main/output/pre_alignment_backup/infer.py:75)。

## 2. 优先解决的实质问题

### A. 论文的 SPA-LoRA 没有对应实现【高】

论文 §3.2、PDF 第 8–9 页、式 (3)–(5) 描述：将视觉 token 划分为 P 个空间部位，每个部位有 E 个专家，通过缺失向量 v 的路由 softmax 动态混合专家。

实际 [LoRALinear.forward](E:/Code/ReID5o-main/output/pre_alignment_backup/model/mmencoder_withlora.py:197) 只按 `lora_index` 取一个低秩增量；[Transformer 路由](E:/Code/ReID5o-main/output/pre_alignment_backup/model/mmencoder_withlora.py:318) 把 `RGB/NIR/CP/SK` 映射到固定索引。调用接口没有输入完整缺失状态 v，也没有 P 分块和每个部位独立的专家混合。

此外，[默认参数](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/options.py:20) 为 `add_lora=False`，不加参数启动时连现有的普通 LoRA 都不开启；`num_loras=4` 是固定适配器数量，不能当作论文的“每个空间部位 E 个专家”。实际实验是否显式启用了 LoRA，需要当时的配置确认。

处理：若另有 SPA-LoRA 实现，应补回实际版本；若没有，需要实现并重新验证对应实验，或据真实实现调整方法名称、公式、结构图及 E/P 实验。仅改 `num_loras` 不能实现论文方法。

### B. CMC → RAF → 最终检索的串行链路没有接通【高】

论文图 2、§3.4–3.6 将补全特征和观测特征一起送入可靠性融合，再由融合表示承担身份检索。

实际主 SDM 在 [build.py:1001](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1001) 对原特征计算，ID 在 [build.py:1133](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1133) 对同一批原特征计算。CMC 训练器 [返回损失字典](E:/Code/ReID5o-main/output/pre_alignment_backup/model/cross_modal_completion.py:557)，RAF 的融合结果则在 [build.py:1125](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1125) 被 `_` 丢弃。

含义：辅助损失仍可能经共享特征影响 backbone，不能说整个模块“完全无效”；但 CMC 生成器没有来自这些主检索损失的梯度路径。把 reconstruction、cycle 两个权重都设为 0 后，当前主路不能再用最终检索目标训练生成器。这与论文损失消融中“只靠最终检索目标优化补全器”的解释不一致。

仓库中已有 [compute_reliability_fusion_with_completion](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:823)，但 AST 调用核查没有找到调用点。函数存在不能证明主流程使用了它。

### C. 测试和推理没有按论文使用 RAF【高】

[Evaluator](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/metrics.py:71) 明确绕过 RAF；多模态 query 直接执行原有 `mm_fusion`。即便配置开启 `use_reliability_fusion_inference`，当前 Evaluator 也没有读取该标志来切换路径。

单模态评估采用固定 0.7/0.3 混合生成 RGB，论文没有交代这个策略；补全异常被 [宽泛捕获并静默忽略](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/metrics.py:114)。因此看到指标输出，不能确认这次评估实际成功执行了补全。

[infer.py](E:/Code/ReID5o-main/output/pre_alignment_backup/infer.py:83) 又没有复用 Evaluator 的缺失感知与补全逻辑。需要统一评估、检索展示和部署接口，否则论文检索图与定量指标可能来自不同处理链路。

### D. 缺少复现测试缺失率实验的协议和入口【高】

论文 §4.1（TeX 第 565 行，PDF 第 17 页）明确说：测试时冻结权重，在 query 和 gallery 上按指定比例确定性删除模态。表 1–4 比较 0%、20%、30%、50%。

当前代码只找到训练时的 `modality_dropout_prob`，以及固定的单/双/三/四模态 query loader。没有找到测试 missing-rate 参数、逐样本 query/gallery mask、固定种子或导出的测试 mask 清单。gallery 读取器也只加载 RGB。

**训练时 dropout 概率、固定查询模态组合、测试时缺失比例，是三个不同的变量。** 修改训练 dropout 后重新训练，不能直接解释为“同一个冻结模型在不同测试缺失率下评估”。如果结果来自外部预处理数据或额外脚本，需要把生成过程和输入文件一起提供，才能复现。

还需定义：缺失比例的分母是什么；只删除 query 辅助模态还是包含 RGB；如何处理全缺失；单 RGB gallery 缺失时保留样本还是删除；不同方法是否共用同一 mask；主表具体报告哪个 query 组合或何种平均。

### E. 补全监督可能使用缺失 token，而非真实目标特征【高】

论文 reconstruction 的目标是“遮挡前提取的真实目标模态特征”。实际 [build.py:1087](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1087) 使用主路径的 `cone_embeds/cone_feats` 构造 `modality_cls_features`；经过训练 dropout 后，这些特征可能已经被缺失 token 替代，却仍传入 `real_features`。

随后 [compute_reconstruction_loss](E:/Code/ReID5o-main/output/pre_alignment_backup/model/cross_modal_completion.py:470) 把该字典的目标项当作真实监督。这样可能训练生成器去拟合缺失占位表示，也可能把其他缺失占位项当作观测上下文。

RAF 同时把这些项 [全部标成 `is_generated=False`](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1120)，没有拿到真实的观测/生成状态；论文中针对生成特征的惩罚，未在这个训练调用中生效。

处理：保留 dropout 前且确实存在的 teacher/目标特征，只从有效观测构造上下文，分别维护“原本可用”“人工遮挡”“生成”三个状态。是否对 teacher 停梯度是实现选择，但不能用占位 token 充当真实目标。

### F. 三模态数据的有效性掩码没有正确贯穿训练【高】

[ImageTextSketchDataset](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/bases.py:562) 用 RGB 作为 NIR、CP 输入占位，并返回 `modality_available` 标志。但模型 forward 没有读取这个标志；[完整分支](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:950) 显式传入五个 True，[warmup 默认分支](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:969) 同样默认五模态存在。因此三模态数据的占位 RGB 会以 NIR/CP 身份进入这些路径。

另一个可复现的问题：先在五模态中保证 `min_keep=2`，再 [强行屏蔽 NIR、CP](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:550)，可能把所有有效模态都清空。

使用现有采样类的原方法、默认概率、Python `random.seed(143)`，得到：

```text
采样后 [RGB,NIR,CP,SK,TEXT] = [False, True, True, False, False]
屏蔽 NIR/CP 后             = [False, False, False, False, False]
```

对 0–9999 这些 seed 进行探测，有 68 次得到这个全缺失结果。这个统计只用于证明分支可达，不是实际训练日志中的故障发生率。应当先限制为数据集真实有效的模态，再在其上采样并保证至少一个有效观测。

## 3. 其他影响方法解释与复现的问题

| 问题 | 已确认的代码事实与影响 |
|---|---|
| RAF 权重结果被后续分支覆盖 | [reliability_adaptive_fusion.py:427](E:/Code/ReID5o-main/output/pre_alignment_backup/model/reliability_adaptive_fusion.py:427) 计算 weighted sum，但默认开启 refinement 后，改用“学习 query + 未加权 context”的 Transformer 输出覆盖它（第 433–452 行）。就此函数的数据依赖而言，返回表示不依赖可靠性权重；权重仍参与辅助正则。|
| RAF 后半部分缺乏被使用的损失路径 | 主 forward 丢弃 RAF 输出，辅助损失仅使用 weights/scores。因此默认训练路径下，`fusion_query`、`fusion_transformer`、`output_proj` 没有来自这些已使用损失的训练路径。此结论来自静态计算依赖，尚未用 PyTorch 实测梯度。|
| 每个 batch 共用一个缺失模式 | [ModalityDropout.forward](E:/Code/ReID5o-main/output/pre_alignment_backup/model/missing_aware_encoding.py:164) 返回长度为 5 的 bool 列表，没有 batch 维；与论文逐样本 v_i 的随机遮挡表述不同。主训练还对缺失的单模态占位特征计算 ID/SDM，应明确哪些损失需要按有效性屏蔽。|
| 一致性损失实际定义更具体 | 代码对 RGB、各单模态及各组合的完整/缺失版本分别对齐再平均（[build.py:1023](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1023)）；论文写成一个完整融合表示与其子集的对齐。应明确对应关系及归一化方式。|
| consistency temperature 没有参与计算 | [ConsistencyConstraint](E:/Code/ReID5o-main/output/pre_alignment_backup/model/missing_aware_encoding.py:394) 保存 temperature，但 cosine 分支只计算 `mean(1-cos)`。论文实现细节的“对比损失温度 0.1”没有实际对应运算。|
| RAF 公式与实现不完全一致 | 论文写两层 MLP，实际可靠性网络有三层 Linear；置信度是两层网络；特征范数也经过 sigmoid。温度实际是可学习参数并下限截断，不只是固定超参数。|
| uncertainty 公式不同 | 论文为 `w × [g + relu(delta-s)]`；[实际实现](E:/Code/ReID5o-main/output/pre_alignment_backup/model/reliability_adaptive_fusion.py:549) 对生成项乘 0.5，对可靠性先 sigmoid，再与阈值 0.5 比较。可选择其中一个定义，但公式和代码要一致。|
| 主检索目标的组合加权未说明 | [build.py:1013](E:/Code/ReID5o-main/output/pre_alignment_backup/model/build.py:1013) 分别平均单/双/三/四模态 SDM，训练器再把四组相加；ID 则平均 16 项。论文把它们简写为 ID+SDM，需交代组间权重和模态缺失时的计算规则。|
| 使用测试集选择 best checkpoint | [datasets/build.py:247](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/build.py:247) 固定用 `dataset.test` 验证，[train.py:368](E:/Code/ReID5o-main/output/pre_alignment_backup/train.py:368) 据此更新 best。`val_dataset` 参数没有被数据构建器使用。测试集参与模型选择，不能再把它当成完全独立的最终测试。|
| 默认不计算 mAP | [options.py:145](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/options.py:145) 为 False；[rank](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/metrics.py:24) 此时返回 mAP=0。论文的 mAP 可能来自显式开启后的实验，需保存相应配置，不能从默认启动复现。|
| 默认训练 20 epochs，论文写 30 | [options.py:119](E:/Code/ReID5o-main/output/pre_alignment_backup/utils/options.py:119)。这可能由训练命令覆盖，只能确认默认不一致，不能据此断言实际只训了 20 轮。|
| 消融开关不便直接关闭模块 | MA/CC/RF 等参数用 `default=True, action='store_true'`，CLI 不能用同名参数设 False。手动 YAML/脚本仍可关闭，但需要补齐实际消融配置。单纯把正则权重设 0 不等于移除模块。|
| 冻结参数开关未生效 | `freeze_vision_encoder` 仅在 options 中定义，未发现读取它的模型逻辑。如果实验意图是冻结整个视觉编码器，需要核查当时版本；现有 LoRA 只在相关层自行冻结部分基础权重。|
| 检索展示写死分类数 | [infer.py:30](E:/Code/ReID5o-main/output/pre_alignment_backup/infer.py:30) 固定 `num_classes=1000`；现有 ORBench 包训练身份数实际为 600，按此数据正常训练的分类器会是 600 类。直接载入这一 checkpoint 的分类器权重将产生形状冲突，需从训练配置恢复类别数。|

## 4. 已有压缩包揭示的数据问题

检查仅使用 ZIP 中央目录和 JSON，没有读取图片像素、解压或搬运数据。

| 压缩包 | 标注行数 / 身份数 | 核查结果 |
|---|---:|---|
| [CUHK-PEDES.zip](E:/Code/ReID5o-main/data/CUHK-PEDES.zip) | 40,206 / 13,003 | 标注没有 `split`；当前 loader 根据路径中的 train/val/test 推断。|
| [ICFG-PDES.zip](E:/Code/ReID5o-main/data/ICFG-PDES.zip) | 54,522 / 4,102 | JSON 有 split，当前包为 train 34,674、test 19,848；身份为 3,102 / 1,000，二者无交集。|
| [RSTPReid.zip](E:/Code/ReID5o-main/data/RSTPReid.zip) | 20,505 / 4,101 | JSON 有 split：train 18,505、val 1,000、test 1,000；压缩包内部直接是 imgs 和 JSON，没有 RSTPReid 顶层目录。|
| [ORBench.zip](E:/Code/ReID5o-main/data/ORBench.zip) | train 27,063 / 600；gallery 18,050 / 400 | 训练/测试身份标签与人员目录均无交集，总计 1,000 身份，与论文总身份数相符。测试 JSON 提供固定查询组合，没有分档缺失率或逐样本可用性 mask。|
| [三个数据集的素描包](<E:/Code/ReID5o-main/data/Tri-CUHK-PEDES, Tri-ICFG-PEDES, and Tri-RSTPReid.zip>) | CUHK 素描 40,206；ICFG 素描 54,521；RSTP 素描 20,505 | 基本目录为 `sketch/aliyun/...`，路径组织需要与 loader 对齐。|

**CUHK 的划分不能直接信任路径关键字。** 包内 readme 解释 `test_query/train_query` 等名称来自组成 CUHK-PEDES 的原始图像数据来源。当前 [划分函数](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/cuhk_pedes.py:156) 没有正式 benchmark 划分信息，仅按路径关键字分组，会得到：train 31,865 张、10,103 身份；test 8,341 张、2,900 身份；val 为空。虽然这两个集合身份不重叠，仍不能证明这就是论文采用的正式划分。需要补论文实验采用的划分文件，而不是继续推断目录名。

**CUHK 有 1,264 条素描配对失败，属于当前代码下可确认的数据读取问题。** RGB 有 `.bmp`，相应素描为 `.jpg`；匹配函数没有处理扩展名变换。例如 `cam_a/376_45.bmp` 对应素描包中的 JPG。当前全路径或 basename 严格匹配会失败，并 [回退为 RGB](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/cuhk_pedes.py:197)。这 1,264 条按当前划分均在训练集，不能把它说成本次已证实的测试集泄漏，但它会让部分 SK 分支读到 RGB。

**三个 loader 都有“找不到 SK 就用 RGB”的回退。** CUHK 见 [第 286 行](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/cuhk_pedes.py:286)，ICFG 见 [第 276 行](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/icfg_pedes.py:276)，RSTP 见 [第 240 行](E:/Code/ReID5o-main/output/pre_alignment_backup/datasets/rstp_reid.py:240)。若将来运行时缺少素描目录，模型可能继续输出看似正常的指标，但 SK 查询实际包含 RGB；ICFG/RSTP 的 gallery 又包含对应 RGB，可能引入直接的同图匹配。应当报错或显式标为缺失，不应静默替换成真实 RGB。

ICFG 素描包比标注行数少一张，但按当前“全路径或 basename”回退规则所有标注都能找到名称候选。这只能说明没有名称级缺失，不能保证候选与 RGB 正确一一配对；仍应在正式数据验收时检查完整相对路径、重复 basename 和实际图像。

## 5. 论文内部已经能确认的矛盾

1. **SPA-LoRA 的 E/P 前后相反。** [实现细节第 569 行](E:/Download/elsarticle-template-num.tex:569) 写 E=3、P=4；[分析第 912 行](E:/Download/elsarticle-template-num.tex:912) 写 E=4、P=3 最优；PDF 第 25 页图 9 也表现为 E=4、P=3 附近更优。即便最终设置有意不选最优，也需要解释，不能直接互相矛盾。
2. **ORBench 的 TEXT+SK 表格与四模态结果混用。** PDF 表 6（第 20 页）TEXT+SK 为 R1=70.21、mAP=60.10，四模态为 R1=89.40、mAP=77.10。表 7（第 21 页）标题却声称 TEXT+SK，在 RGB Rate=90% 列填入 89.40/77.10；两处四指标也完全一致。可能是标题写错或复制了另一组合的结果，需要查原始记录，不能直接猜改哪个数字。
3. **可靠性权重表缺少 RGB 的处理说明。** PDF 表 10 只列 TEXT/IR/CP/SK，四列各行和为 1。论文方法定义以及补全 helper 则包含 RGB。如果先补齐五模态，四列权重和为何为 1，需要说明是排除 RGB、重新归一化，还是另一套统计脚本。仓库没有导出此表的实验脚本。
4. **缺失率增大后的局部性能上升不等于数据错误，但需要解释。** 例如 ICFG 的 20%→30% R1 从 77.06 升至 80.35；RSTP 的 0%→20% R1 从 94.25 升至 94.45。不同 mask 或训练随机性可以导致这种现象，因此应提供同一协议下的种子、重复次数和波动，不能只用“随着缺失增加稳定下降”的叙述概括所有结果。
5. TeX 仍设置 `\journal{Nuclear Physics B}`。若目标期刊为 Pattern Recognition，需要清理这一模板项；这与方法一致性问题独立。

## 6. 已经能对上的部分

不是所有内容都有问题。当前代码确实实现了可学习的模态类型/缺失状态/缺失序列嵌入，cross-attention 生成器，按模态投影并 Stack 的上下文，cosine reconstruction，以及 source→target→source 的 cycle 路径。

图像分辨率 384×128、文本长度 77、LoRA rank 4（启用 LoRA 时）、Adam 基础学习率 1e-5、bias/LoRA 的 2/5 倍学习率规则、cosine scheduler、5 轮学习率 warmup、batch size 8，以及五项辅助损失权重 0.1/0.3/0.1/0.01/0.02，都能找到对应配置或实现。

问题主要在于：模块如何连接、输入状态是否真实、监督目标是否正确、测试走哪条路径，以及实验记录是否完整。上述局部实现并不能自动证明完整 pipeline 已落地。

## 7. 数据集现在需要放吗

**当前任务不用再放，也无需解压已有压缩包。** 本次方法/公式/调用链核查可以静态完成，已有包的标注和目录也足以确认上述具体数据问题。

后续按目标准备即可：

| 后续目标 | 最少需要 |
|---|---|
| 确认当时实际运行的版本与参数 | 产生论文表格的代码快照、训练命令、`configs.yaml`、train/test 日志及表格对应关系；这些比完整图片更优先。|
| 调试输入与补全/融合的一次前向、反向 | 可用 PyTorch 环境；先可用合成张量验证形状、梯度和 mask，再用少量真实配对样本验证读取。无需四个完整数据集。|
| 验证数据划分与配对 | 正式 split 清单、JSON 标注、文件路径清单；已有压缩包可继续用于目录级核查。|
| 核验或重算论文 Rank/mAP、消融、可靠性权重 | 对应 checkpoint、完整测试 query/gallery 数据、固定缺失 mask 与配置；重新训练才需要完整训练集。四个数据集现已有压缩包，但仍需恢复实际实验配置及对应记录。|

真实运行时，数据可保存在其他磁盘目录，通过 `--root_dir` 指定组织好的数据根目录，不必复制进代码仓库。若处理现有 RSTP 压缩包，要注意增加 loader 期望的 RSTPReid 目录层级。不要在素描未就位时直接跑正式实验，因为当前回退机制会掩盖数据缺失。

## 8. 建议处理顺序与验证边界

1. 先冻结并找回产生论文结果的实际代码、配置、checkpoint、日志；建立“表/行 → 数据划分 → query 组合 → train dropout → test missing mask → checkpoint → 指标文件”的对应表。
2. 决定以哪套真实方法为准。如果实际实验版本已经有完整 SPA-LoRA/CMC/RAF，就补回该版本；如果没有，应完成实现后重新实验，或依据已有结果所对应的实际方法重写论文。不能新增实现后继续默认旧表仍然有效。
3. 先修输入有效性、真实特征监督和训练/评估路径，再修 SPA-LoRA 或调整其论述；这些属于方法级变化，应重新核验受影响结果。
4. 建立独立验证集或预先固定模型选择规则；恢复正式划分、固定测试缺失协议，统一 `test.py` 与 `infer.py`。
5. 最后重导出表格与图，再统一 E/P、epoch、损失公式、权重统计的模态范围和实验细节。

本次已完成：原有 31 个 Python 文件语法解析；调用点 AST 核查；默认参数解析；采样逻辑反例复现；33 页 PDF 文本提取及关键图表页目视检查；现有五个 ZIP 的目录、四个数据集的 JSON 标注核查。

本次未完成、也不据此作结论的部分：训练收敛、实际性能提升、历史表格数值真实性、checkpoint 所属方法、真实梯度数值、图片像素级配对。当前可用的系统及工具 Python 均没有 PyTorch，因此没有进行模型级动态执行；语法通过不等于模型可运行。

可复核输出：[核查数据](E:/Code/ReID5o-main/output/audit/audit_checks.json)、[只读探测脚本](E:/Code/ReID5o-main/output/audit/verify_audit.py)。脚本仅需 Python 标准库，不会解压 ZIP 或修改论文、模型、数据。
